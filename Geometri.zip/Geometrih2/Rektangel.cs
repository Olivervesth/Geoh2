﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometri2
{
    class Rektangel : Square
    {

        public void calc5 ()
        {
            t = 1 / 2 * a * b;

            o = a + b + c;
        }
    }
}
