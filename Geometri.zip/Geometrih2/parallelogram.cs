﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometri2
{
    class parallelogram : Square
    {

        public void calc3()
        {
            //Math.Sin returns sine /Math.PI Represents the ratio of the circumference of a circle to its diameter, specified by the constant pi
            double result = a * b * (Math.Sin(hæld * Math.PI /180));
            Console.WriteLine(result);
        }


    }
}
