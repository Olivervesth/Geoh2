﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometri2
{
    class trapez : Square
    {
 
        public void calc4 () 
        {
            double s = (a + b - c + d) /2;
            //math.scrt returns the square root
            double h = 2 /(a-c) * Math.Sqrt (s*(s-a+c)*(s-b)*(s-d));
            Console.WriteLine(s);
            Console.WriteLine(h);

        }

    }
}
