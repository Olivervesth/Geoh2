﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometri2
{
    class Program
    {
           
        static void Main(string[] args)
        {
            Square square = new Square();
            parallelogram parallel = new parallelogram();
            trapez trapez = new trapez();
            Rektangel rektangle = new Rektangel();
            square.a = 1;

            List<Figur> figurlist = new List<Figur>();


            square.Calc();

            square.Calc2();

            parallel.a = 3;
            parallel.b = 5;
            parallel.hæld = 20;
            parallel.calc3();

            // Sets the value's that trapez needs
            trapez.a = 10;
            trapez.b = 9;
            trapez.c = 8;
            trapez.d = 9;
            trapez.calc4();

            
            
            Console.ReadKey();
            
        }
        
    }
}
