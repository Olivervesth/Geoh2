﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometri2
{
    public abstract class Figur
    {
        // All the diffrent prop the figures use for sides 
        public double a { get; set; }
        public double b { get; set; }
        public double c { get; set; }
        public double d { get; set; }
        public double s { get; set; }
        public double h { get; set; }
        public double hæld { get; set; }
        public double t { get; set; }
        public double o { get; set; }
    }
}