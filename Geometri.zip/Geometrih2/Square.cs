﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometri2
{
    class Square : Figur
    {
        public void Calc()
        {
            a = 4 * a;
            Console.WriteLine(a);
           
            
        }

        public void Calc2()
        {
            double A = Math.Pow(a, 2);
            Console.WriteLine(A);
        }
    }
}
